using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SPG_Fachtheorie.Aufgabe3RazorPages.Pages.Konferenz
{
    public class BeschlussModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
