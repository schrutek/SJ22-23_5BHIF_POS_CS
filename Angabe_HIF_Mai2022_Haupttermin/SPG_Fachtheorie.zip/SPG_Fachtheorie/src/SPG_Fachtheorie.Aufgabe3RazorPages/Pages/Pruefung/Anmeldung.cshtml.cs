using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SPG_Fachtheorie.Aufgabe3RazorPages.Pages.Pruefung
{
    public class AnmeldungModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
