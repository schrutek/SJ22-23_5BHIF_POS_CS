﻿namespace SPG_Fachtheorie.Aufgabe2.Model
{
    public class Subject
    {
        public string Shortname { get; set; }
        public string Longmame { get; set; }
    }
}
