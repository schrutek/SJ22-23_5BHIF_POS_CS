﻿using System;

namespace SPG_Fachtheorie.Aufgabe2.Model
{
    public class Class
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
