﻿using Microsoft.AspNetCore.Mvc;

namespace SPG_Fachtheorie.Aufgabe3Mvc.Controllers
{
    public class PruefungController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
